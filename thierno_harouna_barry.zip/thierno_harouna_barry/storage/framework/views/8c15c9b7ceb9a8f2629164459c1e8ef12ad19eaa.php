<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<div class="container">
<table class="table">
  <thead>
    <tr>
      <th scope="col">id</th>
      <th scope="col">nom_classe</th>
      <th scope="col">frais_inscription</th>
      <th scope="col">mensualite</th>
      <th scope="col">frais_tenu</th>
      <th scope="col">frais_amical</th>
      <th scope="col">modifier</th>
      <th scope="col">suprimer</th>
      
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $classe; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $une_classe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td>  <?php echo e($une_classe->id); ?></td>
        <td>  <?php echo e($une_classe->nom_classe); ?></td>
        <td>  <?php echo e($une_classe->frais_inscription); ?></td>
        <td>  <?php echo e($une_classe->mensualite); ?></td>
        <td>  <?php echo e($une_classe->frais_tenu); ?></td>
        <td>  <?php echo e($une_classe->frais_amical); ?></td>
       <td><a href="<?php echo e(route('classe.edit',$une_classe)); ?>"><button type="button" class="btn btn-primary">modifier</button></a></td>
       <td>
          <form action="<?php echo e(route('classe.destroy',$une_classe)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('delete'); ?>
                <button type="submit" class="btn btn-danger">supprimer</button>
          </form>
       </td>

    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  
  
  </tbody>
</table>
    
</div>
<?php /**PATH C:\xampp\htdocs\tout_mes_projet_laravel\thierno_harouna_barry\resources\views/classe/liste.blade.php ENDPATH**/ ?>