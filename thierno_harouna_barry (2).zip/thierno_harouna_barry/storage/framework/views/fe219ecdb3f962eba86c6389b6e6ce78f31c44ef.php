<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title></title>
</head>
<body>
<br>
  <div class="container">
  <form  method="POST" action="<?php echo e(route('encaisser.store')); ?>" >
    <?php echo csrf_field(); ?>

    <select class="form-select" aria-label="Default select example" name="caisse_id">
            <option selected>selectionner une caisse</option>
                <?php $__currentLoopData = $caisse; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $une_caisse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($une_caisse->id); ?>"><?php echo e($une_caisse->prenom_caisse); ?> <?php echo e($une_caisse->nom_caisse); ?></option>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select><br>

          <select class="form-select" aria-label="Default select example" name="etudiant_id">
            <option selected>selectionner un etudiant</option>
                <?php $__currentLoopData = $etudiant; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $un_etudiant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($un_etudiant->id); ?>"><?php echo e($un_etudiant->prenom); ?> <?php echo e($un_etudiant->nom); ?></option>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select><br>
    
        <div class="mb-3">
          <label for="exampleInputEmail1" class="form-label">date_debut:</label>
          <input type="date" name="date_debut" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
        </div>

        <div class="mb-3">
          <label for="exampleInputEmail1" class="form-label">date_fin:</label>
          <input type="date" name="date_fin" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
        </div>

        <div class="mb-3">
          <label for="exampleInputEmail1" class="form-label">heure_encaissement:</label>
          <input type="time" name="heure_encaisse" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
        </div>

        <button type="submit" class="btn btn-primary">Submit</button>
      </form> 

  </div>
          
         

        
   
</body>
</html><?php /**PATH C:\xampp\htdocs\tout_mes_projet_laravel\thierno_harouna_barry\resources\views/encaisser/add.blade.php ENDPATH**/ ?>