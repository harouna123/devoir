<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<div class="container">
<table class="table">
  <thead>
    <tr>
      <th scope="col">id</th>
      <th scope="col">nom</th>
      <th scope="col">prenom</th>
      <th scope="col">naissance</th>
      <th scope="col">sexe</th>
      <th scope="col">lieu</th>
      <th scope="col">diplome</th>
      <th scope="col">nom_tuteur</th>
      <th scope="col">classe_id</th>
      <th scope="col">modifier</th>
      <th scope="col">suprimer</th>
      
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $etudiant; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $un_etudiant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td>  <?php echo e($un_etudiant->id); ?></td>
        <td>  <?php echo e($un_etudiant->nom); ?></td>
        <td>  <?php echo e($un_etudiant->prenom); ?></td>
        <td>  <?php echo e($un_etudiant->naissance); ?></td>
        <td>  <?php echo e($un_etudiant->sexe); ?></td>
        <td>  <?php echo e($un_etudiant->lieu); ?></td>
        <td>  <?php echo e($un_etudiant->diplome); ?></td>
        <td>  <?php echo e($un_etudiant->nom_tuteur); ?></td>
        <td>  <?php echo e($un_etudiant->classe->nom_class); ?></td>
        <td>  <?php echo e($un_etudiant->frais_amical); ?></td>
       <td><a href="<?php echo e(route('etudiant.edit',$un_etudiant)); ?>"><button type="button" class="btn btn-primary">modifier</button></a></td>
       <td>
          <form action="" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('delete'); ?>
                <button type="submit" class="btn btn-danger">supprimer</button>
          </form>
       </td>

    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  
  
  </tbody>
</table>
    
</div>
<?php /**PATH C:\xampp\htdocs\tout_mes_projet_laravel\thierno_harouna_barry\resources\views/etudiant/liste.blade.php ENDPATH**/ ?>