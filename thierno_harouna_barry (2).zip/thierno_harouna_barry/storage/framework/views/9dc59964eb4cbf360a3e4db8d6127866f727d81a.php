<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<div class="container">
<table class="table">
  <thead>
    <tr>
      <th scope="col">id</th>
      <th scope="col">nom_caisse</th>
      <th scope="col">nom_etudiant</th>
      <th scope="col">date_debut</th>
      <th scope="col">date_fin</th>
      <th scope="col">heure_encaissement</th>
      <th scope="col">modifier</th>
      <th scope="col">suprimer</th>
      
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $encaisser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $un_encaissement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td>  <?php echo e($un_encaissement->id); ?></td>
        <td>  <?php echo e($un_encaissement->caisse_id); ?></td>
        <td>  <?php echo e($un_encaissement->etudiant_id); ?></td>
        <td>  <?php echo e($un_encaissement->date_debut); ?></td>
        <td>  <?php echo e($un_encaissement->date_fin); ?></td>
        <td>  <?php echo e($un_encaissement->heure_encaisse); ?></td>
       <td><a href="<?php echo e(route('encaisser.edit',$un_encaissement)); ?>"><button type="button" class="btn btn-primary">modifier</button></a></td>
       <td>
          <form action="<?php echo e(route('encaisser.destroy',$un_encaissement)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('delete'); ?>
                <button type="submit" class="btn btn-danger">supprimer</button>
          </form>
       </td>

    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  
  
  </tbody>
</table>
    
</div>
<?php /**PATH C:\xampp\htdocs\tout_mes_projet_laravel\thierno_harouna_barry\resources\views/encaisser/liste.blade.php ENDPATH**/ ?>