<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<div class="container">
<table class="table">
  <thead>
    <tr>
      <th scope="col">id</th>
      <th scope="col">nom_caisse</th>
      <th scope="col">prenom_caisse</th>
      <th scope="col">niveau</th>
      
      <th scope="col">modifier</th>
      <th scope="col">suprimer</th>
      
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $caisse; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $une_caisse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td>  <?php echo e($une_caisse->id); ?></td>
        <td>  <?php echo e($une_caisse->nom_caisse); ?></td>
        <td>  <?php echo e($une_caisse->prenom_caisse); ?></td>
        <td>  <?php echo e($une_caisse->niveau); ?></td>
       
       <td><a href="<?php echo e(route('caisse.edit',$une_caisse)); ?>"><button type="button" class="btn btn-primary">modifier</button></a></td>
       <td>
          <form action="<?php echo e(route('caisse.destroy',$une_caisse)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('delete'); ?>
                <button type="submit" class="btn btn-danger">supprimer</button>
          </form>
       </td>

    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  
  
  </tbody>
</table>
    
</div>
<?php /**PATH C:\xampp\htdocs\tout_mes_projet_laravel\thierno_harouna_barry\resources\views/caissier/liste.blade.php ENDPATH**/ ?>