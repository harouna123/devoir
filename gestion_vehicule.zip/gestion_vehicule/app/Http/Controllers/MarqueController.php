<?php

namespace App\Http\Controllers;

use App\Models\marque;
use Illuminate\Http\Request;

class MarqueController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $marque=marque::all();
        return view('marque.listeMarque',compact('marque'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('marque.addMarque');

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $request->validate([
                'libelle'=>'required',
        ]);

        $marque=new marque;
        $marque->libelle=$request->libelle;
        $save=$marque->save();

        if($save){
            return redirect(route('marque.index'));
        }


        
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\marque  $marque
     * @return \Illuminate\Http\Response
     */
    public function show(marque $marque)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\marque  $marque
     * @return \Illuminate\Http\Response
     */
    public function edit(marque $marque)
    {
        return view('marque.editMarque',compact('marque'));

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\marque  $marque
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, marque $marque)
    {
        $request->validate([
            'libelle'=>'required',
        ]); 
        $modif = marque::find($marque->id);
        $modif->libelle=$request->libelle;
        $modif->save();
        
        if($modif){
            return redirect(route('marque.index'));
        }

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\marque  $marque
     * @return \Illuminate\Http\Response
     */
    public function destroy(marque $marque)
    {
        $marque->delete();
 
        return redirect(route('marque.index'));
    }
}
