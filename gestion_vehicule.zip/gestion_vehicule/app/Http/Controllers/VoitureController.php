<?php

namespace App\Http\Controllers;

use App\Models\voiture;
use App\Models\marque;
use Illuminate\Http\Request;

class VoitureController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
            
        $voiture = voiture::all();
        return view('voiture.listeVoiture',compact('voiture'));
       
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $marque = marque::all();
        return view('voiture.addVoiture',compact('marque'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'matricule'=>'required',
            'couleur'=>'required',
            'prix'=>'required',
            'marque_id'=>'required',
    ]);

        $voiture=new voiture;
        $voiture->matricule=$request->matricule;
        $voiture->couleur=$request->couleur;
        $voiture->prix=$request->prix;
        $voiture->marque_id=$request->marque_id;
        $save=$voiture->save();
        if($save){
            return redirect(route('voiture.index'));
        }
}

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\voiture  $voiture
     * @return \Illuminate\Http\Response
     */
    public function show(voiture $voiture)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\voiture  $voiture
     * @return \Illuminate\Http\Response
     */
    public function edit(voiture $voiture)
    {
        $marque= marque::all();
       return view('voiture.editVoiture',compact('voiture','marque'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\voiture  $voiture
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, voiture $voiture)
    {
        $request->validate([
            'matricule'=>'required',
            'couleur'=>'required',
            'prix'=>'required',
            
        ]); 
        $modifier = voiture::find($voiture->id);
        $modifier->matricule=$request->matricule;
        $modifier->couleur=$request->couleur;
        $modifier->prix=$request->prix;
        $modifier->marque_id=$request->marque_id;

        $modifier->save();
        
        if($modifier){
            return redirect(route('voiture.index'));
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\voiture  $voiture
     * @return \Illuminate\Http\Response
     */
    public function destroy(voiture $voiture)
    {
        $voiture->delete();
 
        return redirect(route('voiture.index'));
    }
}
