<div class="container">
<form method="post" action="{{route('marque.update',$marque)}}">
    @csrf
    @method('patch')
  <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">libelle</label>
    <input type="text" class="form-control" name="libelle" value="{{$marque->libelle}}" id="exampleInputEmail1" >
   </div>


  <button type="submit" class="btn btn-primary">Submit</button>
</form>
</div>