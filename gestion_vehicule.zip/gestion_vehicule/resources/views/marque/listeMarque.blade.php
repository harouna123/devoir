<table>
   <thead> <th>id</th>
    <th>libelle</th>
    <th>modifier</th>
    <th>suprimer</th>
    
</thead>
<tbody>
    @foreach($marque as $une_marque)
    <tr>
        <td>
            {{$une_marque->id}}
        </td>
        <td>
            {{$une_marque->libelle}}
        </td>
        <td>
            <a href="{{route('marque.edit',$une_marque)}}"><button >modifier</button></a>
            
        </td> 
        <td>
            <form action="{{route('marque.destroy',$une_marque)}}" method="post">
                @csrf
                @method('delete')
                <button type="submit">supprimer</button>
            </form>


        </td> 
   
    </tr>
    @endforeach
</tbody>
   

</table>