<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<div class="container">
<table class="table">
  <thead>
    <tr>
      <th scope="col">id</th>
      <th scope="col">matricule</th>
      <th scope="col">couleur</th>
      <th scope="col">prix</th>
      <th scope="col">marque</th>
      <th scope="col">modifier</th>
      <th scope="col">suprimer</th>
      
    </tr>
  </thead>
  <tbody>
    @foreach($voiture as $une_voiture)
    <tr>
        <td>  {{$une_voiture->id}}</td>
        <td>  {{$une_voiture->matricule}}</td>
        <td>  {{$une_voiture->couleur}}</td>
        <td>  {{$une_voiture->prix}}</td>
        <td>  {{$une_voiture->marque->libelle}}</td>
       <td><a href="{{route('voiture.edit',$une_voiture)}}"><button type="button" class="btn btn-primary">modifier</button></a></td>
       <td>
          <form action="{{route('voiture.destroy',$une_voiture)}}" method="post">
                @csrf
                @method('delete')
                <button type="submit" class="btn btn-danger">supprimer</button>
          </form>
       </td>

    </tr>
    @endforeach
  
  
  </tbody>
</table>
    
</div>
