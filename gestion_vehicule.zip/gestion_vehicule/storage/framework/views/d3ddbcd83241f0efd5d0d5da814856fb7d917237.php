<div class="container">
<form method="post" action="<?php echo e(route('marque.store')); ?>">
    <?php echo csrf_field(); ?>
  <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">libelle</label>
    <input type="text" class="form-control" name="libelle" id="exampleInputEmail1" >
   </div>


  <button type="submit" class="btn btn-primary">Submit</button>
</form>
</div><?php /**PATH C:\xampp\htdocs\tout_mes_projet_laravel\gestion_vehicule\resources\views/marque/addMarque.blade.php ENDPATH**/ ?>