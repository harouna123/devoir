<table>
   <thead> <th>id</th>
    <th>libelle</th>
    <th>modifier</th>
    <th>suprimer</th>
    
</thead>
<tbody>
    <?php $__currentLoopData = $marque; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $une_marque): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td>
            <?php echo e($une_marque->id); ?>

        </td>
        <td>
            <?php echo e($une_marque->libelle); ?>

        </td>
        <td>
            <a href="<?php echo e(route('marque.edit',$une_marque)); ?>"><button >modifier</button></a>
            
        </td> 
        <td>
            <form action="<?php echo e(route('marque.destroy',$une_marque)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('delete'); ?>
                <button type="submit">supprimer</button>
            </form>


        </td> 
   
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
   

</table><?php /**PATH C:\xampp\htdocs\tout_mes_projet_laravel\gestion_vehicule\resources\views/marque/listeMarque.blade.php ENDPATH**/ ?>