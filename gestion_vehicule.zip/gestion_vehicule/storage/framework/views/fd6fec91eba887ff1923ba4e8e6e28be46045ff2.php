<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title></title>
</head>
<body>
    <div class="container">
    <form method="post" action="<?php echo e(route('voiture.update',$voiture)); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('patch'); ?>
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">matricule:</label>
            <input type="number" name="matricule" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"  value="<?php echo e($voiture->matricule); ?>">
        </div>
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">couleur:</label>
            <input type="text" name="couleur" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"  value="<?php echo e($voiture->couleur); ?>">
        </div>

        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">prix:</label>
            <input type="number" name="prix" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"  value="<?php echo e($voiture->prix); ?>">
        </div>
        
        <select class="form-select" aria-label="Default select example" name="marque_id" >
            <option selected value="<?php echo e($voiture->marque_id); ?>"><?php echo e($voiture->marque->libelle); ?></option>
            <?php $__currentLoopData = $marque; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $une_marque): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option  value="<?php echo e($une_marque->id); ?>"><?php echo e($une_marque->libelle); ?></option>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        
        <button type="submit" class="btn btn-primary">Submit</button>
    </form> 

    </div>
   
</body>
</html><?php /**PATH C:\xampp\htdocs\tout_mes_projet_laravel\gestion_vehicule\resources\views/voiture/editVoiture.blade.php ENDPATH**/ ?>