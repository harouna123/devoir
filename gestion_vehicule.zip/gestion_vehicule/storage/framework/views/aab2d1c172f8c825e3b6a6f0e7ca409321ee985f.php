<div class="container">
<form method="post" action="<?php echo e(route('marque.update',$marque)); ?>">
    <?php echo csrf_field(); ?>
    <?php echo method_field('patch'); ?>
  <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">libelle</label>
    <input type="text" class="form-control" name="libelle" value="<?php echo e($marque->libelle); ?>" id="exampleInputEmail1" >
   </div>


  <button type="submit" class="btn btn-primary">Submit</button>
</form>
</div><?php /**PATH C:\xampp\htdocs\tout_mes_projet_laravel\gestion_vehicule\resources\views/marque/editMarque.blade.php ENDPATH**/ ?>